import {
  ChannelType,
  ChatInputCommandInteraction,
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
} from 'discord.js';
import { endReasonLabel, formatDuration, unix } from '../utils/format';
import { checkStaff, safeReply, staffCheckMessage } from './actions';
import { BotContext } from './context';
import { buildPanel } from './panel';

export const slashCommands = [
  new SlashCommandBuilder()
    .setName('set-enterinserv')
    .setDescription('Envía el panel interactivo de servicio al canal actual o especificado')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((option) =>
      option
        .setName('canal')
        .setDescription('Canal donde se publicará el panel (por defecto el canal actual)')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false),
    ),

  new SlashCommandBuilder()
    .setName('vincular')
    .setDescription('Genera un código temporal para vincular tu cuenta de Discord con Roblox'),

  new SlashCommandBuilder()
    .setName('servicio')
    .setDescription('Consulta tu estado actual de servicio, tiempo acumulado y cuenta vinculada'),

  new SlashCommandBuilder()
    .setName('historial')
    .setDescription('Muestra el historial de tus turnos de servicio recientes')
    .addUserOption((option) =>
      option
        .setName('usuario')
        .setDescription('Usuario a consultar (solo administradores)')
        .setRequired(false),
    ),

  new SlashCommandBuilder()
    .setName('horas-staff')
    .setDescription('Consulta las horas de servicio acumuladas de un miembro del staff')
    .addUserOption((option) =>
      option
        .setName('usuario')
        .setDescription('Miembro del staff a consultar (por defecto tú)')
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName('periodo')
        .setDescription('Periodo de tiempo a consultar')
        .setRequired(false)
        .addChoices(
          { name: 'Hoy (Últimas 24 horas)', value: 'day' },
          { name: 'Esta semana (Últimos 7 días)', value: 'week' },
          { name: 'Este mes (Últimos 30 días)', value: 'month' },
          { name: 'Histórico total', value: 'all' },
        ),
    ),

  new SlashCommandBuilder()
    .setName('forzarsalida')
    .setDescription('Fuerza el cierre de la sesión de servicio de un miembro del staff')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addUserOption((option) =>
      option
        .setName('usuario')
        .setDescription('Usuario cuya sesión deseas finalizar')
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName('motivo')
        .setDescription('Motivo de la finalización forzada')
        .setRequired(false),
    ),

  new SlashCommandBuilder()
    .setName('configurar')
    .setDescription('Configura los ajustes del sistema de servicio en este servidor')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addRoleOption((option) =>
      option
        .setName('rol_staff')
        .setDescription('Rol de Discord requerido para utilizar el sistema de servicio')
        .setRequired(true),
    )
    .addChannelOption((option) =>
      option
        .setName('canal_panel')
        .setDescription('Canal sugerido para ubicar el panel de fichaje')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(false),
    ),
];

export async function handleSlashCommand(
  interaction: ChatInputCommandInteraction,
  ctx: BotContext,
): Promise<void> {
  const { commandName } = interaction;

  // 1. /set-enterinserv
  if (commandName === 'set-enterinserv') {
    if (!interaction.inGuild() || !interaction.guildId) {
      await safeReply(interaction, '❌ Este comando solo puede utilizarse en un servidor.');
      return;
    }

    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await safeReply(interaction, '⛔ Necesitas permisos de administración para ejecutar este comando.');
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const targetChannel =
      (interaction.options.getChannel('canal') as typeof interaction.channel) ||
      interaction.channel;

    if (!targetChannel || !('send' in targetChannel)) {
      await interaction.editReply('❌ No se pudo encontrar un canal de texto válido.');
      return;
    }

    try {
      const panelData = buildPanel();
      const message = await targetChannel.send(panelData);

      await ctx.repo.setPanelMessage(interaction.guildId, targetChannel.id, message.id);

      await interaction.editReply(
        `✅ Panel de servicio enviado con éxito en <#${targetChannel.id}>. Los botones ya están operativos.`,
      );
    } catch (err) {
      console.error('[bot] error enviando panel:', err);
      await interaction.editReply('❌ Ocurrió un error al intentar enviar el panel interactivo.');
    }
    return;
  }

  // 2. /vincular
  if (commandName === 'vincular') {
    await interaction.deferReply({ ephemeral: true });

    try {
      const existingLink = await ctx.repo.getLinkByDiscord(interaction.user.id);
      const { display, expiresAt } = await ctx.links.createCode(interaction.user.id);

      const embed = new EmbedBuilder()
        .setTitle('🔗 Vinculación con Roblox')
        .setColor(0x00a8fc)
        .setDescription(
          `Tu código de vinculación es:\n\n# \`${display}\`\n\n` +
            `**Instrucciones:**\n` +
            `1. Entra al juego de Roblox del servidor.\n` +
            `2. Abre el panel de verificación o comando de enlace.\n` +
            `3. Ingresa este código antes de que expire.\n\n` +
            `⏱️ Expira: <t:${unix(expiresAt)}:R> (<t:${unix(expiresAt)}:t>).`,
        )
        .setFooter({ text: 'No compartas este código con nadie.' });

      if (existingLink) {
        embed.addFields({
          name: '⚠️ Cuenta actualmente vinculada',
          value: `Actualmente estás vinculado como **${existingLink.robloxUsername}** (\`${existingLink.robloxUserId}\`). Si completas este nuevo código, tu vinculación se actualizará.`,
        });
      }

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('[bot] error generando código de vinculación:', err);
      await interaction.editReply('❌ No se pudo generar el código temporal de vinculación.');
    }
    return;
  }

  // 3. /servicio
  if (commandName === 'servicio') {
    const staffStatus = await checkStaff(interaction, ctx.repo);
    if (staffStatus !== 'ok') {
      await safeReply(interaction, staffCheckMessage(staffStatus));
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const discordId = interaction.user.id;
    const [link, openSession, totalWeek] = await Promise.all([
      ctx.repo.getLinkByDiscord(discordId),
      ctx.repo.getOpenSessionByDiscord(discordId),
      ctx.repo.getTotalSeconds(discordId, new Date(Date.now() - 7 * 24 * 3600 * 1000)),
    ]);

    const embed = new EmbedBuilder()
      .setTitle('🛡️ Estado de Servicio')
      .setColor(openSession?.status === 'active' ? 0x57f287 : 0xfee75c)
      .setThumbnail(interaction.user.displayAvatarURL())
      .setTimestamp();

    if (link) {
      embed.addFields({
        name: '👤 Cuenta de Roblox',
        value: `**${link.robloxUsername}** (ID: \`${link.robloxUserId}\`)`,
        inline: true,
      });
    } else {
      embed.addFields({
        name: '👤 Cuenta de Roblox',
        value: '❌ *No vinculada* (Usa `/vincular`)',
        inline: true,
      });
    }

    embed.addFields({
      name: '⏱️ Horas esta semana',
      value: `**${formatDuration(totalWeek)}**`,
      inline: true,
    });

    if (!openSession) {
      embed.addFields({
        name: '🔘 Estado Actual',
        value: '🔴 **Fuera de servicio**\nPresiona el botón en el panel para iniciar turno.',
        inline: false,
      });
    } else if (openSession.status === 'pending') {
      const deadline = new Date(openSession.requestedAt.getTime() + ctx.sessions.pendingTtlSeconds * 1000);
      embed.addFields({
        name: '🔘 Estado Actual',
        value:
          `⏳ **Pendiente de ingreso al juego**\n` +
          `Entra al juego con **${openSession.robloxUsername}** antes de <t:${unix(deadline)}:t> (<t:${unix(deadline)}:R>).`,
        inline: false,
      });
    } else if (openSession.status === 'active' && openSession.startedAt) {
      const elapsed = (Date.now() - openSession.startedAt.getTime()) / 1000;
      embed.addFields({
        name: '🔘 Estado Actual',
        value:
          `🟢 **En servicio activo**\n` +
          `• Inicio: <t:${unix(openSession.startedAt)}:T> (<t:${unix(openSession.startedAt)}:R>)\n` +
          `• Transcurrido: **${formatDuration(elapsed)}**\n` +
          `• Servidor JobId: \`${openSession.jobId ?? 'Detectado'}\``,
        inline: false,
      });
    }

    await interaction.editReply({ embeds: [embed] });
    return;
  }

  // 4. /historial
  if (commandName === 'historial') {
    const staffStatus = await checkStaff(interaction, ctx.repo);
    if (staffStatus !== 'ok') {
      await safeReply(interaction, staffCheckMessage(staffStatus));
      return;
    }

    const targetUser = interaction.options.getUser('usuario') || interaction.user;
    const isOther = targetUser.id !== interaction.user.id;

    if (isOther && !interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await safeReply(interaction, '⛔ Solo administradores pueden ver el historial de otros usuarios.');
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const sessions = await ctx.repo.getRecentSessions(targetUser.id, 10);

    const embed = new EmbedBuilder()
      .setTitle(`📜 Historial de Servicio: ${targetUser.username}`)
      .setColor(0x5865f2)
      .setThumbnail(targetUser.displayAvatarURL())
      .setTimestamp();

    if (sessions.length === 0) {
      embed.setDescription('No hay registros de servicio recientes para este usuario.');
    } else {
      const lines = sessions.map((s, idx) => {
        const startStr = s.startedAt ? `<t:${unix(s.startedAt)}:d> <t:${unix(s.startedAt)}:t>` : `<t:${unix(s.requestedAt)}:t>`;
        const durStr = s.durationSeconds !== null ? formatDuration(s.durationSeconds) : 'En curso';
        const reason = s.status === 'active' ? '🟢 En curso' : endReasonLabel(s.endReason);
        return `**${idx + 1}.** ${startStr} — **${durStr}**\n   ↳ Estado: *${reason}* | Jugador: \`${s.robloxUsername}\``;
      });
      embed.setDescription(lines.join('\n\n'));
    }

    await interaction.editReply({ embeds: [embed] });
    return;
  }

  // 5. /horas-staff
  if (commandName === 'horas-staff') {
    const staffStatus = await checkStaff(interaction, ctx.repo);
    if (staffStatus !== 'ok') {
      await safeReply(interaction, staffCheckMessage(staffStatus));
      return;
    }

    const targetUser = interaction.options.getUser('usuario') || interaction.user;
    const period = interaction.options.getString('periodo') || 'week';

    await interaction.deferReply({ ephemeral: true });

    let since: Date;
    let periodName: string;

    const now = Date.now();
    if (period === 'day') {
      since = new Date(now - 24 * 3600 * 1000);
      periodName = 'Últimas 24 horas';
    } else if (period === 'week') {
      since = new Date(now - 7 * 24 * 3600 * 1000);
      periodName = 'Últimos 7 días';
    } else if (period === 'month') {
      since = new Date(now - 30 * 24 * 3600 * 1000);
      periodName = 'Últimos 30 días';
    } else {
      since = new Date(0); // Epoch start
      periodName = 'Histórico total';
    }

    const [totalSecs, link, openSession] = await Promise.all([
      ctx.repo.getTotalSeconds(targetUser.id, since),
      ctx.repo.getLinkByDiscord(targetUser.id),
      ctx.repo.getOpenSessionByDiscord(targetUser.id),
    ]);

    const totalHours = (totalSecs / 3600).toFixed(2);

    const embed = new EmbedBuilder()
      .setTitle(`⏱️ Reporte de Horas: ${targetUser.username}`)
      .setColor(0x57f287)
      .setThumbnail(targetUser.displayAvatarURL())
      .addFields(
        { name: '📅 Periodo', value: periodName, inline: true },
        { name: '⏳ Tiempo Acumulado', value: `**${formatDuration(totalSecs)}**\n(${totalHours} horas)`, inline: true },
        {
          name: '👤 Roblox',
          value: link ? `**${link.robloxUsername}** (\`${link.robloxUserId}\`)` : '*No vinculado*',
          inline: true,
        },
        {
          name: '🔘 Estado Actual',
          value: openSession
            ? openSession.status === 'active'
              ? '🟢 **En servicio activo**'
              : '⏳ **Pendiente de ingreso**'
            : '⚪ **Fuera de servicio**',
          inline: false,
        },
      )
      .setFooter({ text: 'Sistema de Control de Turnos' })
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
    return;
  }

  // 6. /forzarsalida
  if (commandName === 'forzarsalida') {
    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await safeReply(interaction, '⛔ Necesitas permisos de administración para ejecutar este comando.');
      return;
    }

    const targetUser = interaction.options.getUser('usuario', true);
    const reasonText = interaction.options.getString('motivo') || 'Finalizado por un administrador';

    await interaction.deferReply({ ephemeral: true });

    const open = await ctx.repo.getOpenSessionByDiscord(targetUser.id);
    if (!open) {
      await interaction.editReply(`⚠️ El usuario <@${targetUser.id}> no tiene ninguna sesión de servicio activa.`);
      return;
    }

    const result = await ctx.sessions.stop(targetUser.id, reasonText);
    if (result.kind === 'none') {
      await interaction.editReply(`⚠️ No se encontró sesión activa para <@${targetUser.id}>.`);
      return;
    }

    if (result.kind === 'cancelled') {
      await interaction.editReply(`🛑 Se canceló la solicitud pendiente de <@${targetUser.id}>.`);
    } else {
      const dur = formatDuration(result.session.durationSeconds ?? 0);
      await interaction.editReply(
        `✅ Sesión de <@${targetUser.id}> finalizada con éxito.\n• Duración: **${dur}**\n• Motivo: *${reasonText}*`,
      );
    }
    return;
  }

  // 7. /configurar
  if (commandName === 'configurar') {
    if (!interaction.inGuild() || !interaction.guildId) {
      await safeReply(interaction, '❌ Este comando solo puede utilizarse en un servidor.');
      return;
    }

    if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
      await safeReply(interaction, '⛔ Necesitas permisos de administración para ejecutar este comando.');
      return;
    }

    const role = interaction.options.getRole('rol_staff', true);
    const channel = interaction.options.getChannel('canal_panel');

    await interaction.deferReply({ ephemeral: true });

    await ctx.repo.upsertGuildConfig({
      guildId: interaction.guildId,
      staffRoleId: role.id,
      updatedBy: interaction.user.id,
    });

    if (channel) {
      await ctx.repo.setPanelMessage(interaction.guildId, channel.id, '');
    }

    const embed = new EmbedBuilder()
      .setTitle('⚙️ Configuración Guardada')
      .setColor(0x57f287)
      .setDescription(
        `Se han actualizado los parámetros del sistema:\n\n` +
          `• **Rol de Staff Autorizado:** <@&${role.id}>\n` +
          (channel ? `• **Canal de Panel:** <#${channel.id}>\n` : '') +
          `\nYa puedes publicar el panel interactivo usando \`/set-enterinserv\`.`,
      )
      .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
  }
}
